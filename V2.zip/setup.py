import os

os.system('clear')
banner = """\033[92m
   █████  ███    ██ ████████ ██ ███    ██ ███████
  ██   ██ ████   ██    ██    ██ ████   ██ ██
  ███████ ██ ██  ██    ██    ██ ██ ██  ██ █████
  ██   ██ ██  ██ ██    ██    ██ ██  ██ ██ ██
  ██   ██ ██   ████    ██    ██ ██   ████ ███████

  SC BY INFERNALXPLOIT
  Author  : InfernalXploit
  Pembuat : InfernalXploit
  Nomer WhatsApp : 6289648191199
\033[0m"""

print(banner)
print("[1] pip\n[2] pip3\nPILIH 1 APA 2? BAGUS 1 KALO GW MAH TAPI SERAH LU DAH MEK🗿🤓?")
c = input(">>>: ")

if c == "1" or c == "2":
    pip_cmd = "pip" if c == "1" else "pip3"
    
    packages = [
        "cloudscraper", "requests", "socks", "pysocks", "colorama", "setuptools", "pycryptodome",
        "phonenumbers", "art", "dnsutils", "whois", "utils", "pyshorteners", "terminaltables",
        "faker", "pypng", "pyqrcode", "modules", "undetected_chromedriver", "httpx",
        "exifread", "piexif", "rarfile", "pyzipper", "auto-py-to-exe", "selenium", "urllib3",
        "customtkinter", "PyQt5", "PyQtWebEngine", "psutil", "keyboard", "dnspython",
        "deep-translator", "bcrypt", "beautifulsoup4", "pypiwin32", "cryptography",
        "screeninfo", "GPUtil", "discord.py", "discord", "Pillow", "browser-cookie3",
        "opencv-python", "pyautogui", "pycryptodome", "cryptography", "pyzipper", "telebot", "pyfiglet",
    ]

    for pkg in packages:
        os.system(f"{pip_cmd} install {pkg}")

    # Install Google Chrome (khusus Linux)
    if os.name != "nt":
        os.system("wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb")
        os.system("apt-get install -y ./google-chrome-stable_current_amd64.deb")

    print("\n\033[92mSemua instalasi selesai!\033[0m")
    print("\n\033[93mSilakan jalankan perintah berikut untuk menjalankan script:\033[0m")

    # Jalankan setup.sh jika ada
    os.system("bash setup.sh")
else:
    print("\033[91mPilihan tidak valid.\033[0m")
