import base64
import os

os.system("clear" if os.name == "posix" else "cls")

# Banner
print("=" * 50)
print("        ENCODER HTML TO BASE64 [InfernalXploit]")
print("=" * 50)

# Input nama file
input_file = input("Masukkan nama file HTML asli (cth: doxing.html): ").strip()
output_file = input("Masukkan nama file output (cth: hasil.html): ").strip()

try:
    # Baca HTML asli
    with open(input_file, "r", encoding="utf-8") as f:
        html_content = f.read()

    # Encode ke Base64
    encoded = base64.b64encode(html_content.encode()).decode()

    # Bungkus dengan JS auto decode
    final = f"""
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>Encoded</title></head>
<body>
<script>
document.write(atob("{encoded}"));
</script>
</body>
</html>
"""

    # Simpan file hasil
    with open(output_file, "w", encoding="utf-8") as f:
        f.write(final)

    print(f"\nDONE: {output_file} siap jalan 100% normal.")
except FileNotFoundError:
    print(f"\n[ERROR] File '{input_file}' tidak ditemukan.")
except Exception as e:
    print(f"\n[ERROR] Terjadi kesalahan: {e}")
