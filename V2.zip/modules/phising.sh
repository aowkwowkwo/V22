#!/bin/bash

# Membersihkan layar
clear

# Menampilkan banner dengan warna
echo -e "\033[1;32m==============================\033[0m"
echo -e "\033[1;32m  INFERNALXPLOIT CAMERA       \033[0m"
echo -e "\033[1;32m==============================\033[0m"

# Menampilkan menu dengan warna
echo -e "\033[1;31m1. Bukak Bot\033[0m"
echo -e "\033[1;31m2. Exit\033[0m"
echo -n "Pilih opsi: "
read pilihan

if [ "$pilihan" == "1" ]; then
    # Membuka link MediaFire dengan cepat
    echo -e "\033[1;32mMembuka bot...\033[0m"
    xdg-open "https://t.me/Camera_location11_bot" &>/dev/null
elif [ "$pilihan" == "2" ]; then
    echo -e "\033[1;31mKeluar...\033[0m"
    exit
else
    echo -e "\033[1;33mPilihan tidak valid!\033[0m"
fi
