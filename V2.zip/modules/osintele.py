import requests
import os
import json
from colorama import Fore, Style, init

# Initialize colors
init(autoreset=True)
GREEN = Fore.GREEN
RED = Fore.RED
WHITE = Fore.WHITE
CYAN = Fore.CYAN
YELLOW = Fore.YELLOW

# Banner
def banner():
    os.system('cls' if os.name == 'nt' else 'clear')  # Cross-platform clear screen
    print(f"{CYAN}=======================================")
    print(f"{CYAN}TELEGRAM CHECKER TOOL BY INFERNALXPLOIT")
    print(f"{CYAN}=======================================")
    print(f"{YELLOW}Note: You need a bot token with access to the user")
    print(f"{YELLOW}to check username from ID (user must have interacted with bot)\n")

# Check ID to get username
def check_username(user_id, token):
    try:
        url = f"https://api.telegram.org/bot{token}/getChat?chat_id={user_id}"
        response = requests.get(url, timeout=10)
        data = response.json()
        
        if data.get("ok"):
            username = data["result"].get("username", "(No Username)")
            first_name = data["result"].get("first_name", "")
            last_name = data["result"].get("last_name", "")
            full_name = ' '.join(filter(None, [first_name, last_name]))
            
            print(f"\n{GREEN}[+] User Information:")
            if full_name:
                print(f"{GREEN}Name: {full_name}")
            print(f"{GREEN}Username: @{username}")
            print(f"{GREEN}ID: {user_id}")
        else:
            error_msg = data.get("description", "Unknown error")
            print(f"\n{RED}[-] Error: {error_msg}")
            print(f"{YELLOW}Note: The bot may not have access to this user info.")
            print(f"{YELLOW}The user must have started a chat with the bot.")
    except Exception as e:
        print(f"\n{RED}[-] Connection error: {str(e)}")

# Check Token to get bot information
def check_bot_info(token):
    try:
        url = f"https://api.telegram.org/bot{token}/getMe"
        response = requests.get(url, timeout=10)
        data = response.json()
        
        if data.get("ok"):
            bot_name = data["result"].get("first_name", "Unknown")
            bot_username = data["result"].get("username", "Unknown")
            bot_id = data["result"].get("id", "Unknown")
            
            print(f"\n{GREEN}[+] Bot Information:")
            print(f"{GREEN}Bot Name: {bot_name}")
            print(f"{GREEN}Bot Username: @{bot_username}")
            print(f"{GREEN}Bot ID: {bot_id}")
        else:
            error_msg = data.get("description", "Unknown error")
            print(f"\n{RED}[-] Invalid token: {error_msg}")
    except Exception as e:
        print(f"\n{RED}[-] Connection error: {str(e)}")

# Main Program
if __name__ == "__main__":
    while True:
        banner()
        print(f"{WHITE}[1] Check ID for Username")
        print(f"{WHITE}[2] Check Bot Token Info")
        print(f"{WHITE}[3] Check Both ID & Token")
        print(f"{WHITE}[0] Exit")
        
        choice = input(f"\n{CYAN}Select option: ").strip()
        
        if choice == "1":
            user_id = input(f"{CYAN}Enter Telegram ID: ").strip()
            token = input(f"{CYAN}Enter Bot Token: ").strip()  # Token still required to get user info
            check_username(user_id, token)
        elif choice == "2":
            token = input(f"{CYAN}Enter Bot Token: ").strip()
            check_bot_info(token)
        elif choice == "3":
            user_id = input(f"{CYAN}Enter Telegram ID: ").strip()
            token = input(f"{CYAN}Enter Bot Token: ").strip()
            check_username(user_id, token)
            check_bot_info(token)
        elif choice == "0":
            print(f"{RED}Exiting program...")
            break
        else:
            print(f"{RED}Invalid choice!")
        
        input(f"\n{CYAN}Press Enter to continue...")

