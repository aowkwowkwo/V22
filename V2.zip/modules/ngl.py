import requests
import time
import uuid
import random
import os

# Clear screen
os.system("clear" if os.name == "posix" else "cls")

# Banner
banner = """
\033[1;36m╔═╗\033[1;37m╦═╗\033[1;31m╦  \033[1;36m╔═╗\033[1;37m╦═╗\033[1;31m╔═╗\033[1;36m╔╦╗\033[1;37m  ╔═╗\033[1;31m╔═╗\033[1;36m╦═╗
\033[1;36m║  \033[1;37m╠╦╝\033[1;31m║  \033[1;36m║╣ \033[1;37m╠╦╝\033[1;31m╠═╣\033[1;36m║║║\033[1;37m  ╠═╣\033[1;31m╠═╣\033[1;36m╠╦╝
\033[1;36m╚═╝\033[1;37m╩╚═\033[1;31m╩═╝\033[1;36m╚═╝\033[1;37m╩╚═\033[1;31m╩ ╩\033[1;36m╩ ╩\033[1;37m  ╩ ╩\033[1;31m╩ ╩\033[1;36m╩╚═
       \033[1;37m[\033[1;31m+\033[1;37m] \033[1;36mInfernalXploit NGL Spammer
"""

print(banner)

# Input
ngl_link = input("\033[1;37m[\033[1;31m?\033[1;37m] Masukkan link NGL (contoh: https://ngl.link/sennaaak_): ").strip()
username = ngl_link.split("/")[-1]
pesan = input("\033[1;37m[\033[1;31m?\033[1;37m] Masukkan pesan yang ingin dikirim: ").strip()
jumlah = int(input("\033[1;37m[\033[1;31m?\033[1;37m] Masukkan jumlah pengiriman: "))

# Endpoint dan headers
url = "https://ngl.link/api/submit"
user_agents = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
    "Mozilla/5.0 (Linux; Android 11; SM-A107F)",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X)",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:86.0) Gecko/20100101 Firefox/86.0"
]

# Kirim pesan
print("\n\033[1;37m[\033[1;31m!\033[1;37m] Mengirim pesan...\n")

for i in range(jumlah):
    data = {
        "username": username,
        "question": f"{pesan} #{i+1}",
        "deviceId": str(uuid.uuid4())
    }
    headers = {
        "User-Agent": random.choice(user_agents),
        "Content-Type": "application/x-www-form-urlencoded"
    }
    try:
        response = requests.post(url, data=data, headers=headers)
        if response.status_code == 200:
            print(f"\033[1;32m[{i+1}] BERHASIL dikirim!")
        else:
            print(f"\033[1;31m[{i+1}] GAGAL ({response.status_code})")
    except Exception as e:
        print(f"\033[1;31m[{i+1}] ERROR: {e}")
    time.sleep(2)

print("\n\033[1;37m[\033[1;32m✓\033[1;37m] Selesai semua!")
